import React from "react";
import { Container, Row, Col } from "reactstrap";
// core components

import IndexNavbar from "components/Navbars/IndexNavbar.js";

function Dating() {
    document.documentElement.classList.remove("nav-open");
    return (
        <>
            <IndexNavbar transparentUntilScrolled={false} />
            <div className="header-1">

                <div
                    className="page-header"
                    style={{
                        backgroundImage: `url(/img/events/dating-header.jpg)`
                    }}
                >
                </div>
            </div>

            <Container className="article-content">
                <Row className="title" >

                    <h2>Alpakawanderung x Speed Dating</h2>
                </Row>
                <Row>
                    <Col>
                        <h3>Das Speed – Dating mit Alpakas</h3>

                        <p>Vielleicht findet unser Alpaka Carlos, der Date Doktor, für dich die große Liebe?
                            Bei unserem Alpaka Speed – Dating nehmen wir euch mit auf eine geführte
                            Wanderung. Hier wird nicht wie im klassischen Speed – Dating nach ein paar
                            Minuten der „Tisch gewechselt“, sondern ihr tauscht alle 5 Minuten das Alpaka. So
                            seid ihr immer mit einem anderen Alpaka - und einem Wanderpartner des anderen
                            Geschlechts unterwegs.</p>
                        <p>Die etwas andere und lockere Form des Speed Datings!</p>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <h3>Ablauf</h3>

                        <p> Wir starten das Speed Dating vor der Wanderung mit einem gemeinsamen Glas
                            Sekt. Dann bekommen die weiblichen Wanderer ein Alpaka zugeteilt, mit welchem sie
                            die Wanderung absolvieren. Jedem Frau und jedem Alpaka wird im Anschluss ein Mann zugeteilt.
                            Wenn die Tiere verteilt sind, laufen wir los. Im Laufe der Wanderungen bekommt jeder Mann die Möglichkeit, jedes Alpaka und jede Frau kennenzulernen.</p>
                        <p>Nach der Wanderung darf jeder/jede einen Zettel abgeben, mit den Namen derer an denen Interesse besteht.
                            Nur wenn eine Übereinstimmung vorliegt, also wenn Mann und Frau sich beide gut
                            finden, übernimmt unser Team die Weitergabe der Telefonnummern der beiden
                            Teilnehmer an den jeweils anderen.</p>
                    </Col>
                </Row>
                <Row>
                    <Col md="12">
                        <h3>Speed Dating Termine für 2022</h3>
                        <h5>
                            <ul>
                                <li>5.11.2022 - 15:00 bis 17:00 Uhr<br />20 - 33 Jahre - Tickets für Frauen verfügbar</li>
                                <li>19.11.2022 - 15:00 bis 17:00 Uhr<br />30 - 45 Jahre - Tickets für Männer verfügbar</li>
                                <li>26.11.2022 - 15:00 bis 17:00 Uhr<br />43 - 60 Jahre - Tickets für Männer verfügbar</li>
                            </ul>
                        </h5>
                        <p>Für die Altersgruppe ab 60 Jahren gibt es eine Warteliste, genauso für die Gruppe "Mann sucht Mann" und "Frau sucht Frau". Bei genügend Anmeldungen werden in diesen Gruppen neue Termine bekannt gegeben.</p>
                            <p>Wenn wir dich auf der Warteliste notieren sollen, schreib uns gerne eine E-Mail über das Kontaktformular mit deinem Namen, deinem Alter sowie deiner Telefonnummer. Wir kontaktieren dich dann sofort, sobald ein Termin gefunden werden kann.</p>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <h3>Preise</h3>
                        30 € pro Person
                    </Col>
                </Row>

                <Row>
                    <Col>
                        <h3><strong>Termin buchen</strong></h3>
                        Schreib uns eine E-Mail, wenn du ein Ticket buchen möchtest. Termine für den Herbst werden wir im Juli veröffentlichen.
                    </Col>
                </Row>

            </Container>
        </>
    );
}
export default Dating;
