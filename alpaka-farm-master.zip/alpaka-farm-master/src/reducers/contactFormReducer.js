import { SEND_CONTACT_FORM } from "../actions/types";

const reducer = (state = {}, action) => {
  switch (action.type) {
    case SEND_CONTACT_FORM:
      return { ...state, [action.payload.id]: action.payload };
    default:
      return state;
  }
};
export default reducer;
