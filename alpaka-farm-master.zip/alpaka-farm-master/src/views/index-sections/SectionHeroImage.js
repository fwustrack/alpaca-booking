import React from "react";

// reactstrap components
import { Container } from "reactstrap";

function SectionHeroImage() {
  return (
    <>
      <div
        className="page-header section-dark"
        style={{
          backgroundImage: "url(/img/eugene-woronyuk-large.jpg)",
        }}
      >
        <div className="filter" />
        <div className="content-center">
          <Container>
            <div className="title-brand">
              <h2 className="presentation-title">Alpakas vom Rosenhof</h2>
            </div>
            <h2 className="presentation-subtitle text-center"></h2>
          </Container>
        </div>
        <div
          className="moving-clouds"
          style={{
            backgroundImage: "url(img/clouds.png)",
          }}
        />
      </div>
    </>
  );
}

export default SectionHeroImage;
