/* Amplify Params - DO NOT EDIT
  ENV
  REGION
  STORAGE_FORMTABLE_ARN
  STORAGE_FORMTABLE_NAME
Amplify Params - DO NOT EDIT */

var awsServerlessExpressMiddleware = require("aws-serverless-express/middleware");
var bodyParser = require("body-parser");
var express = require("express");
var app = express();
var cors = require("cors"); // ADDED - for avoiding CORS in local dev
app.use(cors()); // ADDED - for avoiding CORS in local dev
app.use(bodyParser.json());
app.use(awsServerlessExpressMiddleware.eventContext());
var axios = require("axios");

/* 1. Import the AWS SDK and create an instance of the DynamoDB Document Client */
var AWS = require("aws-sdk"),
  region = process.env.REGION,
  recaptchaSecret = "alpakafarm/recaptchaSecret";
var docClient = new AWS.DynamoDB.DocumentClient();
var ses = new AWS.SES();
var secretsManager = new AWS.SecretsManager({ region: region });
var receiver = "info@alpakas-vom-rosenhof.de";
//var receiver = "felix.wustrack@gmail.com";

function id() {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

async function getSecret(secretName) {
  secretsManager.getSecretValue({ SecretId: secretName }, function (err, data) {
    if (err) {
      throw err;
    } else {
      return data.SecretString;
    }
  });
}

async function getCaptchaResult(body) {
  const captchaResponse = body.captchaResponse;
  console.log("captcha for " + captchaResponse);
  const apikey = await getSecret(recaptchaSecret);
  const url = "https://www.google.com/recaptcha/api/siteverify";

  const ret = await axios
    .post(url, null, {
      params: {
        secret: "6LeKl5oaAAAAAItt3CKZTN2o8TWfW6bXCYxgWcII",
        response: captchaResponse,
      },
    })
    .then((response) => {
      console.log("capchta result " + JSON.stringify(response.data, null, 2));
      return response.data;
    })
    .catch((error) => {
      console.log(error.response.status);
      console.log(error.response.data);
      console.log(error.response.headers);
      return error;
    });
  return ret;
}

async function sendMail(body) {
  let name = body.name;
  let email = body.email;
  let message = body.message;
  let messagebody = "Name: " + name + "\nEmail: " + email + "\n \n" + message;
  try {
    await ses
      .sendEmail({
        Source: "info@alpakas-vom-rosenhof.de",
        Destination: {
          ToAddresses: [receiver],
        },
        ReplyToAddresses: [email],
        Message: {
          Subject: {
            Data: "Neue Nachricht vom Kontaktformular",
          },
          Body: {
            Text: {
              Data: messagebody,
            },
          },
        },
      })
      .promise();
  } catch (err) {
    throw err;
  }
}

async function saveInDynamoDB(body) {
  var params = {
    TableName: process.env.STORAGE_FORMTABLE_NAME,
    Item: {
      id: id(),
      name: body.name,
      email: body.email,
      message: body.message,
    },
  };
  try {
    docClient.put(params);
  } catch (err) {
    throw err;
  }
}

app.post("/contact", async function (req, res) {
  try {
    //const result = await getCaptchaResult(req.body);
    //if (result.success) {
    console.log("sending message");
    await sendMail(req.body);
    await saveInDynamoDB(req.body);
    //} else {
    //  console.log("Captcha failed for: " + req);
    //  console.log("Reason: " + result);
    // }
    res.json({ success: "Nachricht empfangen!" });
  } catch (err) {
    res.json({ err });
  }
});

app.listen(3000, function () {
  console.log("App started");
});

// Export the app object. When executing the application local this does nothing. However,
// to port it to AWS Lambda we will create a wrapper around that will load the app from
// this file
module.exports = app;
