import React from "react";
// reactstrap components
import { Container, Card, Row, Col, Button } from "reactstrap";

function SectionYoga() {
    return (
        <div className="section text-center">
            <Container>
                <Row>



                    <Col className="ml-auto m-3" md="5" >

                        <Row >
                            <Col className="description">
                                <h3 className="info-title">Yoga auf der Alpakawiese</h3>
                                <h5>
                                    In den frühen Morgenstunden den Tag mit einer Stunde Yoga in der Natur genießen - inmitten der friedlichen und süßen Alpakas auf der Wiese.
                                </h5>
                            </Col>
                        </Row>
                        <Row className="m-3">
                            <Col>
                                <Button
                                    className="btn-round"
                                    color="primary"
                                    href="/events/yoga"
                                    outline
                                >
                                    mehr Infos
                                </Button>
                            </Col>
                        </Row>

                    </Col>
                    <Col className="ml-auto m-3" md="5">
                        <Card className="card-plain">
                            <img className="img-fluid" alt="..." src={"/img/events/yoga-2.jpg"} />
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div >
    );
}
export default SectionYoga;
