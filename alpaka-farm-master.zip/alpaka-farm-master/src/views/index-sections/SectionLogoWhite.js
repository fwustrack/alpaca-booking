import React from "react";
// reactstrap components
import { Container, Row, Col } from "reactstrap";
function SectionLogoWhite() {
  return (
    <div className="section">
      <Container>
        <Row>
          <Col className="ml-auto mr-auto text-center" md="8">
            <img
              className="img-fluid"
              alt="..."
              src={"img/logo_web_500px.png"}
            />
          </Col>
        </Row>
      </Container>
    </div>
  );
}
export default SectionLogoWhite;
