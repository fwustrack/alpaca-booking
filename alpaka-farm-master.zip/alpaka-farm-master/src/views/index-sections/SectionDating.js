import React from "react";
// reactstrap components
import { Container, Row, Col, Button } from "reactstrap";

function SectionDating() {
    return (
        <div className="section text-center">
            <Container>
                <Row className="d-flex justify-content-center">
                    <h2>Alpakawanderung x Speed – Dating</h2>
                </Row>
                <Row>



                    <Col className="ml-auto m-3" md="5" >

                        <Row >
                            <Col className="description">
                                <h3 className="info-title">Das Speed – Dating mit Alpakas</h3>
                                <h5>
                                    Vielleicht findet unser Alpaka Carlos, der Date Doktor, für dich die große Liebe?
                                    <br />
                                    Wann und wie erfahrt ihr hier:
                                </h5>
                            </Col>
                        </Row>
                        <Row className="m-3">
                            <Col>
                                <Button
                                    className="btn-round"
                                    color="primary"
                                    href="/events/dating"
                                    outline
                                >
                                    zum Dating - Event
                                </Button>
                            </Col>
                        </Row>

                    </Col>
                    <Col className="ml-auto m-3" md="5">
                        <img className="img-fluid" alt="..." src={"/img/speed-dating.gif"} />
                    </Col>
                </Row>
            </Container>
        </div >
    );
}
export default SectionDating;
