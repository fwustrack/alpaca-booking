import React from "react";
// reactstrap components
import { Container, Row, Col} from "reactstrap";

function SectionCorona() {
  return (
    <div className="section text-center">
      <Container className="alert-warning">
        <Row>
          <Col className="ml-auto m-3" >


              <h3 className="info-title">Corona Regeln für unsere Veranstaltungen</h3>
              <h5 >
              Bei unseren Events gilt derzeit ab einer Teilnehmerzahl von 10 Personen die 2G Regel. Halten Sie vor Start des Events Ihren Impf- oder Genesenennachweis sowie Ihren Personalausweis bereit. 
              </h5>


          </Col>

        </Row>
      </Container>
    </div>
  );
}
export default SectionCorona;
